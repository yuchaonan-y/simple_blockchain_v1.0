#pragma once

namespace appbase {
   extern const char* appbase_version_string;
}