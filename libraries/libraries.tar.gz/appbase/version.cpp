namespace appbase {
   const char* appbase_version_string = "UnKnown";
}